
public class Dummy {

	//int f;
	
	public static void main(String ...a)
	{
	 
	  System.out.println("dsfndsavfjdshj");
	}
	
}
